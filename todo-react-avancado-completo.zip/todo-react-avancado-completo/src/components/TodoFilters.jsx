import React from 'react'

function setFilter(f){
  document.body.dataset.filter = f
  window.dispatchEvent(new Event('filterchange'))
}

function TodoFiltersInner(){
  return (
    <div className="filters">
      <button onClick={() => setFilter('all')}>Todas</button>
      <button onClick={() => setFilter('pending')}>Pendentes</button>
      <button onClick={() => setFilter('done')}>Concluídas</button>
    </div>
  )
}

export default React.memo(TodoFiltersInner)
