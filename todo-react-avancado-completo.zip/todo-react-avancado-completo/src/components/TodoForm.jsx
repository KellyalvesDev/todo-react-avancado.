import React, { useState } from 'react'
import { useTodoContext } from '../context/TodoContext'

export default function TodoForm(){
  const { addTodo } = useTodoContext()
  const [text, setText] = useState('')

  function handleSubmit(e){
    e.preventDefault()
    addTodo(text)
    setText('')
  }

  return (
    <form onSubmit={handleSubmit} className="todo-form">
      <input
        placeholder="Adicione uma nova tarefa..."
        value={text}
        onChange={e => setText(e.target.value)}
      />
      <button type="submit">Adicionar</button>
    </form>
  )
}
