import React from 'react'
import { useTodoContext } from '../context/TodoContext'

function TodoItemInner({ todo }){
  const { toggleTodo, removeTodo } = useTodoContext()

  return (
    <li className={'todo-item ' + (todo.done ? 'done' : '')}>
      <label>
        <input type="checkbox" checked={todo.done} onChange={() => toggleTodo(todo.id)} />
        <span>{todo.text}</span>
      </label>
      <button onClick={() => removeTodo(todo.id)}>Remover</button>
    </li>
  )
}

export default React.memo(TodoItemInner, (prev, next) => prev.todo === next.todo)
