import React, { useMemo } from 'react'
import { useTodoContext } from '../context/TodoContext'
import TodoItem from './TodoItem'

export default function TodoList(){
  const { todos, stats } = useTodoContext()
  const filter = document.body.dataset.filter || 'all'

  const filtered = useMemo(() => {
    if (filter === 'done') return todos.filter(t => t.done)
    if (filter === 'pending') return todos.filter(t => !t.done)
    return todos
  }, [todos, filter])

  return (
    <section className="todo-list">
      <div className="summary">
        <span>Total: {stats.total}</span>
        <span>Feitas: {stats.done}</span>
        <span>Pendentes: {stats.pending}</span>
      </div>
      <ul>
        {filtered.length === 0 && <li>Nenhuma tarefa</li>}
        {filtered.map(t => <TodoItem key={t.id} todo={t} />)}
      </ul>
    </section>
  )
}
