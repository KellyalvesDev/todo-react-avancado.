import { useCallback, useMemo } from 'react'
import useLocalStorage from './useLocalStorage'
import { simpleId } from '../utils_uuid'

export default function useTodos(){
  const [todos, setTodos] = useLocalStorage('todos:v1', [])

  const addTodo = useCallback((text) => {
    if (!text || !text.trim()) return
    setTodos(prev => [{ id: simpleId(), text: text.trim(), done: false }, ...prev])
  }, [setTodos])

  const toggleTodo = useCallback((id) => {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t))
  }, [setTodos])

  const removeTodo = useCallback((id) => {
    setTodos(prev => prev.filter(t => t.id !== id))
  }, [setTodos])

  const clearAll = useCallback(() => setTodos([]), [setTodos])

  const stats = useMemo(() => {
    const total = todos.length
    const done = todos.filter(t => t.done).length
    return { total, done, pending: total - done }
  }, [todos])

  return {
    todos,
    addTodo,
    toggleTodo,
    removeTodo,
    clearAll,
    stats
  }
}
