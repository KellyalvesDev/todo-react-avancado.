export function simpleId(){
  return Math.random().toString(36).slice(2,9) + Date.now().toString(36).slice(-4)
}
