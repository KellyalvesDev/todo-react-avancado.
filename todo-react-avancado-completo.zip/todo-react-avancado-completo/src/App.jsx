import React from 'react'
import TodoForm from './components/TodoForm'
import TodoList from './components/TodoList'
import TodoFilters from './components/TodoFilters'

export default function App(){
  return (
    <div className="app">
      <header>
        <h1>Todo React Avançado</h1>
        <p>Exemplo com Hooks, Context API, Hooks customizados e memoization</p>
      </header>
      <main>
        <TodoForm />
        <TodoFilters />
        <TodoList />
      </main>
      <footer>
        <small>Feito como exercício — estrutura completa</small>
      </footer>
    </div>
  )
}
