import React, { createContext, useContext } from 'react'
import useTodos from '../hooks/useTodos'

const TodoContext = createContext()

export const TodoProvider = ({ children }) => {
  const todosHook = useTodos()
  return (
    <TodoContext.Provider value={todosHook}>
      {children}
    </TodoContext.Provider>
  )
}

export const useTodoContext = () => {
  const ctx = useContext(TodoContext)
  if (!ctx) throw new Error('useTodoContext must be used within TodoProvider')
  return ctx
}
