import { useState } from 'react'

export default function App() {
  const [todos, setTodos] = useState([])
  const [text, setText] = useState('')

  const addTodo = () => {
    if (!text.trim()) return
    setTodos([...todos, text])
    setText('')
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Todo React Avançado</h1>
      <input value={text} onChange={e=>setText(e.target.value)} />
      <button onClick={addTodo}>Adicionar</button>

      <ul>
        {todos.map((t,i)=> <li key={i}>{t}</li>)}
      </ul>
    </div>
  )
}
