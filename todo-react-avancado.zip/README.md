# Todo React Avançado

Aplicação de Todo List usando React, Context API, Hooks, Hook customizado e Memoization.

## 🚀 Tecnologias
- React
- Vite
- Context API
- Hooks
- useMemo
- React.memo

## ✔ Funcionalidades
- Adicionar tarefa  
- Marcar como concluída  
- Remover  
- Filtros (todas, concluídas, pendentes)  
- Persistência no localStorage  

## ▶ Como Rodar

1. Instale o Node.js (versão LTS)
2. Baixe o projeto ou clone o repositório
3. No terminal, execute:

```
npm install
npm run dev
```

4. Abra no navegador o link exibido no terminal.

Pronto! ✔
