import TodoForm from "./components/TodoForm";
import TodoList from "./components/TodoList";
import TodoFilters from "./components/TodoFilters";
import { TodoContext } from "./context/TodoContext";
import { useContext } from "react";

export default function App() {
  const { todos } = useContext(TodoContext);

  return (
    <div className="container">
      <h1>Todo List Avançado</h1>
      <TodoForm />
      <TodoFilters />
      <TodoList todos={todos} />
    </div>
  );
}
