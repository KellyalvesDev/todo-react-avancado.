import { TodoContext } from "../context/TodoContext";
import { useContext } from "react";

export default function TodoFilters() {
  const { setFilter } = useContext(TodoContext);

  return (
    <div className="filters">
      <button onClick={() => setFilter("all")}>Todas</button>
      <button onClick={() => setFilter("completed")}>Concluídas</button>
      <button onClick={() => setFilter("pending")}>Pendentes</button>
    </div>
  );
}
