import { createContext, useState, useMemo } from "react";
import useLocalStorage from "../hooks/useLocalStorage";

export const TodoContext = createContext();

export function TodoProvider({ children }) {
  const [storedTodos, setStoredTodos] = useLocalStorage("todos", []);
  const [filter, setFilter] = useState("all");

  const filteredTodos = useMemo(() => {
    if (filter === "completed") return storedTodos.filter(t => t.completed);
    if (filter === "pending") return storedTodos.filter(t => !t.completed);
    return storedTodos;
  }, [storedTodos, filter]);

  function addTodo(text) {
    const newTodo = { id: Date.now(), text, completed: false };
    setStoredTodos([...storedTodos, newTodo]);
  }

  function toggleTodo(id) {
    setStoredTodos(storedTodos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  }

  function removeTodo(id) {
    setStoredTodos(storedTodos.filter(todo => todo.id !== id));
  }

  return (
    <TodoContext.Provider value={{
      todos: filteredTodos,
      addTodo,
      toggleTodo,
      removeTodo,
      setFilter
    }}>
      {children}
    </TodoContext.Provider>
  );
}
